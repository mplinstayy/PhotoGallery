package com.bignerdranch.android.photogallery.api

import com.bignerdranch.android.photogallery.PhotoResponse

class FlickrResponse {
    lateinit var photos: PhotoResponse
}